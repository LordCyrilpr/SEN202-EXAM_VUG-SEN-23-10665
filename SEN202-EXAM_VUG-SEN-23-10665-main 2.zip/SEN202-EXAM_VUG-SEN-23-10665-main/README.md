# SEN202-EXAM_VUG-SEN-23-10665
SEN202: Software Construction Practical
Question1,Question2 and Question3
Login to Django Admin at http://127.0.0.1:8000/admin/ with:
Username: admin
Email: nwadichidubem@gmail.com
Password: Cyril@20